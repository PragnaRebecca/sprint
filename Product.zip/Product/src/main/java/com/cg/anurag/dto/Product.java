package com.cg.anurag.dto;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="Product")
public class Product
{
	@Column(name="name")
	private String name;
	@Column(name="product_id")
	private String productId;
	@Column(name="distributor_id")
	private double distributorId;
	@Column(name="ware_house_id")
	private double wareHouseId;
	@Column(name="quantity_value")
	private double quantityValue;
	@Column(name="quantity_unit")
	private double quantityUnit;
	@Column(name="price_per_unity")
	private double pricePerUnit;
	@Column(name="date_of_delivery")
	private Date dateOfDelivery;
	public Product(){}
	public Product(String name,String productId, double distributorId, double wareHouseId, double quantityValue, int quantityUnit,
			double pricePerUnit, Date dateOfDelivery) {
		super();
		this.name = name;
		this.productId = productId;
		this.distributorId = distributorId;
		this.wareHouseId = wareHouseId;
		this.quantityValue = quantityValue;
		this.quantityUnit = quantityUnit;
		this.pricePerUnit = pricePerUnit;
		this.dateOfDelivery = dateOfDelivery;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String productId() {
		return productId;
	}
	public void setProductId(String orderId) {
		this.productId = productId;
	}
	public double getDistributorId() {
		return distributorId;
	}
	public void setDistributorId(double distributorId) {
		this.distributorId = distributorId;
	}
	public double getWareHouseId() {
		return wareHouseId;
	}
	public void setWareHouseId(double wareHouseId) {
		this.wareHouseId = wareHouseId;
	}
	public double getQuantityValue() {
		return quantityValue;
	}
	public void setQuantityValue(double quantityValue) {
		this.quantityValue = quantityValue;
	}
	public double getQuantityUnit() {
		return quantityUnit;
	}
	public void setQuantityUnit(double quantityUnit) {
		this.quantityUnit = quantityUnit;
	}
	public double getPricePerUnit() {
		return pricePerUnit;
	}
	public void setPricePerUnit(double pricePerUnit) {
		this.pricePerUnit = pricePerUnit;
	}
	public Date getDateOfDelivery() {
		return dateOfDelivery;
	}
	public void setDateOfDelivery(Date dateOfDelivery) {
		this.dateOfDelivery = dateOfDelivery;
	}	
}