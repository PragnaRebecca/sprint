package com.cg.anurag.dto;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;

@Entity
public class ProductStock 
{
	@Column(name="distributer_id")
	private double distributerId;
	@Column(name="delivery_status")
	private String deliveryStatus;
	@Column(name="start_date")
	private Date startDate;
	@Column(name="end_date")
	private Date endDate;
	@Column(name="product_id")
	private String productId;
	@Column(name="name")
	private String name;
	@Column(name="price_per_unit")
	private double pricePerUnit;
	@Column(name="quantity_value")
	private double quantityValue;
	@Column(name="quantity_unit")
	private double quantityUnit;
	@Column(name="price")
	private double price;
	@Column(name="ware_house_id")
	private String wareHouseId;
	@Column(name="delivery_date")
	private Date deliveryDate;
	@Column(name="manufacture_date")
	private Date manufactureDate;
	@Column(name="expiry_date")
	private Date expiryDate;
	@Column(name="quality_check")
	private String qualityCheck;
	@Column(name="process_date")
	private Date processDate;
	public ProductStock(){}
	public ProductStock(double distributerId, String deliveryStatus, Date startDate, Date endDate, String productId,
			String name, double pricePerUnit, double quantityValue, double quantityUnit, double price,
			String wareHouseId, Date deliveryDate, Date manufactureDate, Date expiryDate, String qualityCheck,
			Date processDate) {
		super();
		this.distributerId = distributerId;
		this.deliveryStatus = deliveryStatus;
		this.startDate = startDate;
		this.endDate = endDate;
		this.productId = productId;
		this.name = name;
		this.pricePerUnit = pricePerUnit;
		this.quantityValue = quantityValue;
		this.quantityUnit = quantityUnit;
		this.price = price;
		this.wareHouseId = wareHouseId;
		this.deliveryDate = deliveryDate;
		this.manufactureDate = manufactureDate;
		this.expiryDate = expiryDate;
		this.qualityCheck = qualityCheck;
		this.processDate = processDate;
	}
	public double getDistributerId() {
		return distributerId;
	}
	public void setDistributerId(double distributerId) {
		this.distributerId = distributerId;
	}
	public String getDeliveryStatus() {
		return deliveryStatus;
	}
	public void setDeliveryStatus(String deliveryStatus) {
		this.deliveryStatus = deliveryStatus;
	}
	public Date getStartDate() {
		return startDate;
	}
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	public Date getEndDate() {
		return endDate;
	}
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	public String productId() {
		return productId;
	}
	public void setProductId(String orderId) {
		this.productId = productId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getPricePerUnit() {
		return pricePerUnit;
	}
	public void setPricePerUnit(double pricePerUnit) {
		this.pricePerUnit = pricePerUnit;
	}
	public double getQuantityValue() {
		return quantityValue;
	}
	public void setQuantityValue(double quantityValue) {
		this.quantityValue = quantityValue;
	}
	public double getQuantityUnit() {
		return quantityUnit;
	}
	public void setQuantityUnit(double quantityUnit) {
		this.quantityUnit = quantityUnit;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public String getWareHouseId() {
		return wareHouseId;
	}
	public void setWareHouseId(String wareHouseId) {
		this.wareHouseId = wareHouseId;
	}
	public Date getDeliveryDate() {
		return deliveryDate;
	}
	public void setDeliveryDate(Date deliveryDate) {
		this.deliveryDate = deliveryDate;
	}
	public Date getManufactureDate() {
		return manufactureDate;
	}
	public void setManufactureDate(Date manufactureDate) {
		this.manufactureDate = manufactureDate;
	}
	public Date getExpiryDate() {
		return expiryDate;
	}
	public void setExpiryDate(Date expiryDate) {
		this.expiryDate = expiryDate;
	}
	public String getQualityCheck() {
		return qualityCheck;
	}
	public void setQualityCheck(String qualityCheck) {
		this.qualityCheck = qualityCheck;
	}
	public Date getProcessDate() {
		return processDate;
	}
	public void setProcessDate(Date processDate) {
		this.processDate = processDate;
	}
}
