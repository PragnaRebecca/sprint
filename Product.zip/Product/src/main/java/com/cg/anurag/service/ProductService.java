package com.cg.anurag.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.anurag.dao.ProductDao;
import com.cg.anurag.dto.Product;

@Service
public class ProductService {
	 @Autowired
	    ProductDao Pdao;
	    public void setBdao(ProductDao pdao) { this.Pdao=pdao;}
	    @Transactional
	    public Product insertProduct(Product product)
	    {
	        return Pdao.save(product);
	    }
	    @Transactional(readOnly=true)
	    public Product getProduct(int productId)
	    {
	    	return Pdao.findById(productId).get();
	    }
	    @Transactional(readOnly=true)
	    public List<Product> getBooks()
	    {
	    	return Pdao.findAll();
	    }
	    @Transactional
	    public String deleteProduct(int productId)
	    {
	    	Pdao.deleteById(productId);
	    	return "Product Deleted";
	    }
	    
	    @Transactional
	    public String updateProduct(Product newProduct)
	    {
	    	Product product = Pdao.findById(newProduct.productId()).get();
	    	if(product!=null)
	    	{
	    	  product.setName(newProduct.getName());
	    	   product.setProductId(newProduct.productId());
	    	  return "Product Modified";
	    	}
	    	return "Update Failed";
	    }
	    
	}
