package com.cg.anurag.test;

import java.util.ArrayList;
import java.util.List;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.cg.anurag.dto.PlaceAnOrderProduct;

public class TestCase 
{
	
	@Test
	public void testPositiveCase() 
	{
		List<PlaceAnOrderProduct> arr = new ArrayList();
		arr = p.placeAnOrder();
		if(arr.size()>0)
			a=1;
		Assert.assertEquals(a,1);
	}
	@Test
	public void testNegativeCase() 
	{
		List<PlaceAnOrderProduct> arr = new ArrayList();
		arr = p.placeAnOrder();
		if(arr.size()>0)
			a=1;
	}

}
