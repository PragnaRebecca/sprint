package com.cg.anurag.dao;

import java.util.List;

import com.cg.anurag.dto.DisplayProduct;
import com.cg.anurag.dto.PlaceAnOrderProduct;
public interface ProductDao 
{
	public void openConnection();
	public void close();
	public List<PlaceAnOrderProduct> placeAnOrder();
	public DisplayProduct display(double distributorid);
}
