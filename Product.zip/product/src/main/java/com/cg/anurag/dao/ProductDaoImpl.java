package com.cg.anurag.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.anurag.dto.DisplayProduct;
import com.cg.anurag.dto.PlaceAnOrderProduct;
import com.cg.anurag.utility.Query;


public class ProductDaoImpl implements ProductDao
{
	private Connection connection = null;
	private PreparedStatement pst;
	private ResultSet result,result1;
	@Override
	public void openConnection() {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			String url = "jdbc:oracle:thin:@localhost:1521:xe";
			connection = DriverManager.getConnection(url, "Akhilesh", "akhil");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void close() {
		try {
			connection.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	@Override
	public List<PlaceAnOrderProduct> placeAnOrder() {
		List<PlaceAnOrderProduct> plist = new ArrayList<>();
		openConnection();
		try {
			pst = connection.prepareStatement(Query.productDetails);
			result1 = pst.executeQuery();
			while(result1.next())
			{
				PlaceAnOrderProduct p = new PlaceAnOrderProduct();
				p.setName(result1.getString(1));
				p.setDistributorId(result1.getDouble(2));
				p.setWareHouseId(result1.getDouble(3));
				p.setPricePerUnit(result1.getDouble(4));
				plist.add(p);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return plist;
	}


	@Override
	public DisplayProduct display(double distributorId) {
		openConnection();
		DisplayProduct p = null;
		try {
			pst = connection.prepareStatement(Query.productInfo);
			pst.setDouble(1, distributorId);
			result = pst.executeQuery();
			if(result.next())
			{
				p = new DisplayProduct();
				p.setOrderId(result.getString(1));
				p.setName(result.getString(2));
				p.setPricePerUnit(result.getDouble(3));
				p.setQuantityValue(result.getDouble(4));
				p.setQuantityUnit(result.getDouble(5));
				p.setPrice(result.getDouble(6));
				p.setWareHouseId(result.getString(7));
				p.setDeliveryDate(result.getDate(8));
				p.setManufactureDate(result.getDate(9));
				p.setExpiryDate(result.getDate(10));
				p.setQualityCheck(result.getString(11));
				p.setProcessDate(result.getDate(12));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		close();
		return p;
	}

	
	
	}



