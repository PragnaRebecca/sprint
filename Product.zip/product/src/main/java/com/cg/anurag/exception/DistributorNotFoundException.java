package com.cg.anurag.exception;

public class DistributorNotFoundException extends Exception
{
	public DistributorNotFoundException()
	{
		super("Please Enter Valid Distributor Id");
	}
}

