package com.cg.anurag.exception;

public class ProductNotFoundException extends Exception
{
	public ProductNotFoundException()
	{
		super("Please Enter Available Product Name");
	}
}

