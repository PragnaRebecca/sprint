package com.cg.anurag.exception;

public class SupplierNotFoundException extends Exception
{
	public SupplierNotFoundException()
	{
		super("Please Enter Available Supplier Id");
	}
}

