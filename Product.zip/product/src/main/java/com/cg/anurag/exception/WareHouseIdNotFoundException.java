package com.cg.anurag.exception;

public class WareHouseIdNotFoundException extends Exception
{
	public WareHouseIdNotFoundException()
	{
		super("Please Enter Valid WareHouseId");
	}
}

