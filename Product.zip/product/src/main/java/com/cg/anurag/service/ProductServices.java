package com.cg.anurag.service;

import java.util.List;

import com.cg.anurag.dto.DisplayProduct;
import com.cg.anurag.dto.PlaceAnOrderProduct;

public interface ProductServices 
{
	public List<PlaceAnOrderProduct> placeAnOrder();
	public DisplayProduct display(double distributorId);
}
