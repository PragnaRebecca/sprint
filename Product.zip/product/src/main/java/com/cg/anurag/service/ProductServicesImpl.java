package com.cg.anurag.service;

import java.util.List;

import com.cg.anurag.dao.ProductDao;
import com.cg.anurag.dao.ProductDaoImpl;
import com.cg.anurag.dto.DisplayProduct;
import com.cg.anurag.dto.PlaceAnOrderProduct;

public class ProductServicesImpl implements ProductServices
{
	ProductDao dao = new ProductDaoImpl();
	@Override
	public List<PlaceAnOrderProduct> placeAnOrder() {
		return dao.placeAnOrder();
	}
	
	@Override
	public DisplayProduct display(double distributorId) {
		return dao.display(distributorId);
	}

	}
	

