package com.cg.anurag.utility;

public class Query 
{
	public static String productInfo = "select * from productstock where distributorid=?";
	public static String rawMaterialInfo = "select * from rawmaterialstock where supplierid=?";
	public static String rawMaterialDetails = "select * from rawmaterials";
	public static String insertRawMaterial = "insert into rawmaterialorders values(?,?,?,?,?,?)";
	public static String productDetails = "select * from products";
	public static String insertProduct = "insert into productorders values(?,?,?,?,?,?)";

}
