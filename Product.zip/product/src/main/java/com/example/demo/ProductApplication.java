package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import com.cg.anurag.dto.DisplayProduct;
import com.cg.anurag.dto.PlaceAnOrderProduct;
import com.cg.anurag.service.ProductServices;
import com.cg.anurag.service.ProductServicesImpl;

import java.util.List;
import java.util.Scanner;

@SpringBootApplication
public class ProductApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProductApplication.class, args);
		Scanner sc = new Scanner(System.in);
		ProductServices ps = new ProductServicesImpl();
		try
		{
			List<PlaceAnOrderProduct> plist = ps.placeAnOrder();
			System.out.println("Name\t\tdistributorid\twarehouseid\tpriceperunit");
			for(PlaceAnOrderProduct p : plist)
			System.out.println(p.getName()+"\t"+p.getDistributorId()+"\t\t"+p.getWareHouseId()+"\t\t"+p.getPricePerUnit());
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		try
		{
		DisplayProduct dp = ps.display(25);
		System.out.println(dp.getOrderId()+" "+dp.getName()+" "+dp.getPricePerUnit()+" "+
		dp.getQuantityValue()+" "+dp.getQuantityUnit()+" "+dp.getPrice()+" "+dp.getWareHouseId()+
		" "+dp.getDeliveryDate()+" "+dp.getManufactureDate()+" "+dp.getExpiryDate()+" "+
		dp.getQualityCheck()+" "+dp.getProcessDate());
		}
		catch(NullPointerException e)
		{
			System.out.println("No Product");
		}
	}

}


